from django.apps import AppConfig


class ChatServerAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'chat_server_app'
